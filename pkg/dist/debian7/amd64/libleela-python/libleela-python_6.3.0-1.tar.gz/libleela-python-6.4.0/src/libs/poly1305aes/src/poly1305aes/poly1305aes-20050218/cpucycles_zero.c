/*
cpucycles_zero.c version 20050218
D. J. Bernstein
Public domain.
*/

#include "cpucycles_zero.h"

long long cpucycles_zero(void)
{
  return 0;
}
