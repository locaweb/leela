require "rspec"
require_relative "../lib/leela_ruby"

RSpec.configure do |config|
end
